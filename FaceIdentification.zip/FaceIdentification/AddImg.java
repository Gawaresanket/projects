import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import javax.swing.JComboBox.*;
import java.lang.String.*;
import java.awt.image.*;
import javax.imageio.*;

class New1 extends JFrame implements ActionListener
{
	String imgfile="";
	boolean imgstatus=false;
	String msg[]={"Male","Female"};
	int i;

	ImageIcon ico;
	Image img;
	File f1=null;
	
	JLabel head=new JLabel("Insert Image");
	JLabel photo=new JLabel("		Photo	");

	JLabel l1=new JLabel("Enter Image Id");
	
	JLabel l13=new JLabel("Image Path");

	JTextField t1=new JTextField(20);
	JTextField t6=new JTextField(20);
	
	JComboBox c=new JComboBox();
	JComboBox da=new JComboBox();
	JComboBox mo=new JComboBox();
	JComboBox yr=new JComboBox();

	JButton b2=new JButton("Ok");
	JButton b3=new JButton("Exit");
	JButton b4=new JButton(".......");
	JButton b5=new JButton("Clear");
	int criminalid=0;

	Connection con;
	Statement stmt;

	New1()
	{
		super("Add Image");
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
            Database d1=new Database();
    		Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/my","root","root");
    			/*System.out.println("connection successfully.....");
    			con.close();    */         
			stmt=con.createStatement();
            ResultSet rs=stmt.executeQuery("select max(id) from img");
			if(rs.next())
			{
             String crimid=rs.getString(1);
             if(crimid!=null)
			criminalid=Integer.parseInt(crimid);
                }
                criminalid++;	
                }catch(Exception e)
		{
                    JOptionPane.showMessageDialog(this, e.getMessage(), "Criminal Details", JOptionPane.ERROR_MESSAGE);
		}
			
			Container cp=getContentPane();
			cp.setLayout(null);
			setSize(650,700);
			setResizable(false);

			java.awt.Dimension screen=java.awt.Toolkit.getDefaultToolkit().getScreenSize();
			java.awt.Rectangle frame=getBounds();
			this.setLocation((screen.width-frame.width)/2,(screen.height-frame.height)/2);


			head.setFont(new Font("Times New Roman",Font.BOLD/Font.ITALIC,25));
			head.setForeground(Color.blue);
			head.setBounds(200,10,250,30);
			cp.add(head);

			photo.setFont(new Font("Times New Roman",Font.BOLD/Font.ITALIC,20));
			
			photo.setBounds(200,150,200,260);
			photo.setBorder(BorderFactory.createTitledBorder(""));
			cp.add(photo);

			c.addItem("Select");
			for(int i=0;i<2;i++)
				c.addItem(msg[i]);

			da.addItem("dd");        
		    for(int i=1;i<=31;i++)
		    da.addItem(i+"");	  
    				
			mo.addItem("mm");
			String month[]={"January","February","March","April","May","June","July","August","September","October","November","December"};
		    for(int i=0;i<12;i++)
			mo.addItem(month[i]);	  
			
			yr.addItem("yy");
			for(int i=1970;i<=2020;i++)
			yr.addItem(i+"");	  

			t1.setText(criminalid+"");
			t1.setEditable(false);
			
			//t2.requestFocus();
			l1.setBounds(20,50,100,30);
			t1.setBounds(120,50,215,30);
	
		
			
			
			l13.setBounds(20,530,100,30);
			t6.setBounds(120,530,215,30);
			b4.setBounds(340,530,80,30);
			
			cp.add(l1);cp.add(t1);
			
			cp.add(l13);cp.add(t6);cp.add(b4);

			b2.setBounds(40,610,85,30);
			b3.setBounds(200,610,85,30);
			b5.setBounds(360,610,85,30);
			cp.add(b2);cp.add(b3);cp.add(b5);

			b2.addActionListener(this);
			b3.addActionListener(this);
			b4.addActionListener(this);
			b5.addActionListener(this);
			
	}
		public void actionPerformed(ActionEvent ae)
		{
			JButton b=(JButton)ae.getSource();
			if(b==b2)
			{
				try
				{
			int  cid=Integer.parseInt(t1.getText());
		/*	String firstname=t2.getText();
			String lastname=t3.getText();
			String aliasname=t4.getText();
			/*String dob=da.getSelectedItem().toString();
			int mob=mo.getSelectedIndex();
			String yob=yr.getSelectedItem().toString();
			String age=t5.getText();
			String gender=c.getSelectedItem().toString();
			String address=t7.getText();
			String city=t8.getText();
			String state=t9.getText();
			String arresteddate=t10.getText();
			String crimeinvolved=t11.getText();*/
			String photo=t6.getText();

			String str="insert into img(id,photo) values(" + cid + ",'" + photo + "')";
            int res=stmt.executeUpdate(str);
			if(res==1)
			JOptionPane.showMessageDialog(this,"Record Inserted");
			}catch(Exception e)
			{
				JOptionPane.showMessageDialog(this,e.getMessage(),"New Criminal", JOptionPane.ERROR_MESSAGE);
			}
				
	}
		
	else if(b==b5)
	{

		/*t2.setText("");
		t3.setText("");
		t4.setText("");
		t5.setText("");
		t6.setText("");
		t7.setText("");
		t8.setText("");
		t9.setText("");
		t10.setText("");
		t11.setText("");*/
		photo.setIcon(new ImageIcon("Icons\\anand.bmp"));
		/*c.setSelectedItem("Select");
		da.setSelectedItem("dd");
		mo.setSelectedItem("mo");
		yr.setSelectedItem("yy");*/
	}
else if(b==b4)
	{
		JFileChooser jfc=new JFileChooser("select a file");
		jfc.showOpenDialog(this);
		imgstatus=true;
		f1=jfc.getSelectedFile();
		t6.setText(f1.getName());
		imgfile=f1.getPath();
		ico=new ImageIcon(imgfile);
		photo.setIcon(ico);
       
	}
else if(b==b3)
{
	setVisible(false);
	dispose();
}
}

	class MyPanel extends Canvas
	{
		Toolkit tkt;
		MyPanel()
		{
			tkt=Toolkit.getDefaultToolkit();
		}
		public void paint(Graphics g)
		{
			if(imgstatus)
			{
				Image img=tkt.getImage(imgfile);
				g.drawImage(img,0,0,this);	
			}
		}
	}

}

class AddImg
{
//@SuppressWarnings("deprecation")
public static void main(String ar[])
{
	New1 ob=new New1();
	ob.setVisible(true);
}
}





