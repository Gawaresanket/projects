import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.*;
public class demo extends JFrame
{
	demo()
	{
		Font f=new Font("serif",Font.BOLD,30);
		//header
		JPanel heading,h1,h2;
		
		heading=new JPanel();
		heading.setBackground(new Color(0,0,0,80));
		heading.setBounds(0,0,900,100);
		JLabel name=new JLabel("Welcome To Navajeevan Society");
		name.setForeground(Color.WHITE);
		name.setBounds(300,80,600,100);
		name.setFont(f);
		heading.add(name);
		
		
		//login pannel
		JPanel login=new JPanel();
		login.setLayout(null);
		login.setSize(400,350);
		login.setBackground(new Color(0,0,0,80));

		
		
		Container con=getContentPane();
		JLabel j1=new JLabel("LOGIN HERE");
		j1.setBounds(340,170,400,80);
		j1.setForeground(Color.ORANGE);
		j1.setBackground(new Color(0,0,0,80));
		j1.setFont(f);
		con.add(j1);
		JTextField username=new JTextField("Enter Username");
		//con.add(username);
		username.setBounds(50,50,300,50);
		username.setOpaque(false);
		username.setForeground(Color.WHITE);
		username.setBackground(new Color(210,180,140));
		

		login.add(username);
		
		//password text box
		JPasswordField password=new JPasswordField("Enter Password");
		password.setBounds(50,130,300,50);
		password.setOpaque(false);
		password.setForeground(Color.WHITE);
		password.setBackground(new Color(210,180,140));
		login.add(password);
		
		/*String str[]= {"<Select Gate No>","1","2","3","4"};
		final JComboBox jbox=new JComboBox(str);
		jbox.setBounds(50,210,300,30);
		jbox.setOpaque(false);
		jbox.setForeground(Color.black);
		//jbox.setBackground(new Color(210,180,80));
		login.add(jbox);/
		*/
		
		//signup button
		JButton signup=new JButton("Sign up");
		signup.setBounds(250,270,100,50);
		//signup.setBackground(new Color(160,182,45));
		login.add(signup);
		
		signup.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent args0)
			{
				second frm11=new second();
				frm11.setVisible(true);
			}
		});
				
		
		//login button
		JButton login_button=new JButton("Login");
		login_button.setBounds(50,270,100,50);
		//login_button.setBackground(new Color(160,182,45));
		login.add(login_button);
		login_button.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				try {//mysql-connector-java-8.0.28.tar.gz
					Class.forName("com.mysql.cj.jdbc.Driver");  
					Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/ABC","root","Sanket@123");  
					Statement stmt=con.createStatement();  
					
					ResultSet rs=stmt.executeQuery("select * from username_pass where username='"+username.getText()+"' and password='"+password.getText().toString()+"'");  
					if(rs.next())  
					{
						JOptionPane.showMessageDialog(null, "login Successfully....");  
						fourth frm=new fourth();
						frm.setVisible(true);
					}	
					else
						JOptionPane.showMessageDialog(null, "Incorrect Username and Password....");
					con.close();  			
				} catch (SQLException | ClassNotFoundException e) {
					System.out.println("Error while connection datbase");
					e.printStackTrace();
				}
			}
		});
		
		login.setBounds(250,175,400,350);

		//frame
		setSize(900,600);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//image
		ImageIcon background_image=new ImageIcon("/home/sanketjalindargaware/my phone/Anime/your name//best.jpg");
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(900, 600, Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		JLabel background=new JLabel("",background_image,JLabel.CENTER);
		background.add(login);

		background.add(heading);
		background.setBounds(0,0,900,600);
		add(background);
		setVisible(true);
	}
	public static void main(String[] args) 
	{
		new demo();
		
	}

}
