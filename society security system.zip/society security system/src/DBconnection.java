import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class DBconnection
{

	public static void main(String[] args) throws java.sql.SQLException
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");  
		Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/sample","root","Sanket@123");
			System.out.println("connectio successfully.....");
			Scanner sc=new Scanner(System.in);
			System.out.println("enter first name");
			String fname=sc.next();
			System.out.println("enter middle name");
			String mname=sc.next();
			System.out.println("enter last name");
			String lname=sc.next();
			System.out.println("enter mb no");
			String mno=sc.next();
			System.out.println("enter email");
			String email=sc.next();
		

			String s="insert into sampleinfo values('"+mno+"','"+fname+"','"+mname+"','"+lname+"','"+email+"')";
			PreparedStatement stmt=con.prepareStatement(s);
			stmt.execute();
			System.out.println("insert success");
			
			//PreparedStatement stmt1=con.prepareStatement("select * from sampleinfo");
			Statement stmt1=con.createStatement();
			ResultSet rs=stmt1.executeQuery("select * from sampleinfo");
			int i=1;
			
			mno=rs.getString(1);
			fname=rs.getString(2);
			mname=rs.getString(3);
			lname=rs.getString(4);
			email=rs.getString(5);
			while(rs.next())
			{
			System.out.println("\ninfo\n"+mno+"\n"+fname+"\n"+mname+"\n"+lname+"\n"+email);
			}
			con.close();  			
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println("Error while connection datbase");
			e.printStackTrace();
		}
	}
}
