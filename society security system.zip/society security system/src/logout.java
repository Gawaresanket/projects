import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class logout extends JFrame
{
	logout()
	{
		setBackground(UIManager.getColor("Button.foreground"));
		getContentPane().setForeground(Color.WHITE);
		getContentPane().setBackground(new Color(51, 0, 204));
		Font f=new Font("serif",Font.BOLD,30);
		//header
		JPanel heading,h1,h2;

		//frame
		setSize(1280,800);
		getContentPane().setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	
		
		
		
		JPanel login1=new JPanel();
		login1.setBorder(UIManager.getBorder("Menu.border"));
		getContentPane().add(login1);
		login1.setLayout(null);
		login1.setSize(400,350);
		login1.setBackground(new Color(ALLBITS));
		login1.setBounds(-11,112,1,600);

		
	
		
		
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(UIManager.getBorder("InternalFrame.optionDialogBorder"));
		panel_2.setBounds(429, 273, 355, 160);
		getContentPane().add(panel_2);
		panel_2.setBackground(new Color(0,0,8,80));
		panel_2.setLayout(null);
		
		JLabel lblAddOwnerDetails = new JLabel("Do You Wants To Log Out?");
		lblAddOwnerDetails.setForeground(new Color(255, 255, 255));
		lblAddOwnerDetails.setBounds(12, 5, 358, 107);
		lblAddOwnerDetails.setFont(new Font("Dialog", Font.BOLD, 22));
		panel_2.add(lblAddOwnerDetails);
		
		JButton btnAdd_1 = new JButton("No");
		btnAdd_1.setBackground(UIManager.getColor("List.dropLineColor"));
		btnAdd_1.setBounds(22, 123, 101, 25);
		panel_2.add(btnAdd_1);
		
		JButton btnYes = new JButton("Yes");
		btnYes.setBounds(226, 123, 101, 25);
		panel_2.add(btnYes);
		btnYes.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				demo frm1=new demo();
				frm1.setVisible(true);
			}
		});
		
		btnAdd_1.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				home frm1=new home();
				frm1.setVisible(true);
			}
		});
		
		/*JLabel label1=new JLabel("");
		
		label1.setBounds(2,12,1283,326);
		getContentPane().add(label1);*/
		
		ImageIcon background_image=new ImageIcon("//home//sanketjalindargaware//Downloads//natalya-letunova-DLclPZyS_bs-unsplash.jpg");
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1285, 800, Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		JLabel background3=new JLabel("",background_image,JLabel.CENTER);

		//background.add(heading);
		background3.setBounds(0,0,1285,736);
		getContentPane().add(background3);
		
		

	}
	public static void main(String[] args) 
	{
		new home();
		
	}
}
