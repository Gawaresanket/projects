import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;

public class second {

	private JFrame frame;
	private JTextField fname;
	private JTextField mname;
	private JTextField lname;
	private JTextField mno;
	private JTextField email;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		new second(); 
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new second(); 
					second window = new second();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public second() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 596, 474);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		fname = new JTextField();
		fname.setBounds(261, 98, 235, 29);
		frame.getContentPane().add(fname);
		fname.setColumns(10);
		
		JLabel lblFillTheInformation = new JLabel("Fill the Information");
		lblFillTheInformation.setFont(new Font("Dialog", Font.BOLD, 22));
		lblFillTheInformation.setBounds(164, 12, 304, 52);
		frame.getContentPane().add(lblFillTheInformation);
		
		JLabel FirstName = new JLabel("First name");
		FirstName.setFont(new Font("Dialog", Font.BOLD, 18));
		FirstName.setBounds(91, 92, 114, 39);
		frame.getContentPane().add(FirstName);
		
		JLabel lblMiddleName = new JLabel("Middle Name");
		lblMiddleName.setFont(new Font("Dialog", Font.BOLD, 18));
		lblMiddleName.setBounds(91, 143, 147, 29);
		frame.getContentPane().add(lblMiddleName);
		
		mname = new JTextField();
		mname.setBounds(261, 144, 235, 29);
		frame.getContentPane().add(mname);
		mname.setColumns(10);
		
		JLabel lblLastName = new JLabel("Last Name");
		lblLastName.setFont(new Font("Dialog", Font.BOLD, 18));
		lblLastName.setBounds(91, 189, 137, 41);
		frame.getContentPane().add(lblLastName);
		
		lname = new JTextField();
		lname.setBounds(261, 196, 235, 29);
		frame.getContentPane().add(lname);
		lname.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Phone Number");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 18));
		lblNewLabel.setBounds(91, 247, 168, 20);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblEmailId = new JLabel("Email Id");
		lblEmailId.setFont(new Font("Dialog", Font.BOLD, 18));
		lblEmailId.setBounds(91, 279, 168, 43);
		frame.getContentPane().add(lblEmailId);
		
		mno = new JTextField();
		mno.setBounds(261, 237, 235, 30);
		frame.getContentPane().add(mno);
		mno.setColumns(10);
		
		email = new JTextField();
		email.setBounds(261, 279, 235, 29);
		frame.getContentPane().add(email);
		email.setColumns(10);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBounds(88, 348, 117, 25);
		frame.getContentPane().add(btnBack);
		
		JButton btnNext = new JButton("Next");
		btnNext.setBounds(351, 348, 117, 25);
		frame.getContentPane().add(btnNext);
		btnNext.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");  
					Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/ABC","root","Sanket@123");  
					String a=fname.getText();
					String b=mname.getText();
					String c=lname.getText();
					String i=mno.getText();
					int d=Integer.parseInt(i);
					String e=email.getText();

					String s="insert into u_info values('"+a+"','"+b+"','"+c+"','"+e+"','"+d+"')";
					PreparedStatement stmt=con.prepareStatement(s);
					stmt.execute();
					System.out.println("success");
					
					con.close();  			
				} catch (SQLException | ClassNotFoundException e) {
					System.out.println("Error while connection datbase");
					e.printStackTrace();
				}
			}
		});
	}

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}

		
}

