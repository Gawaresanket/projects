import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.JTable;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.BevelBorder;

public class ShowDetails extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ShowDetails frame = new ShowDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ShowDetails() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(UIManager.getColor("EditorPane.inactiveForeground"));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblVisitorsRecords = new JLabel("Visitors Records");
		lblVisitorsRecords.setVerticalAlignment(SwingConstants.TOP);
		lblVisitorsRecords.setForeground(Color.BLACK);
		lblVisitorsRecords.setFont(new Font("P052", Font.BOLD, 30));
		lblVisitorsRecords.setBounds(522, 12, 265, 76);
		contentPane.add(lblVisitorsRecords);
		
		table = new JTable();
		table.setShowHorizontalLines(false);
		table.setShowGrid(false);
		table.setShowVerticalLines(false);
		table.setFillsViewportHeight(true);
		table.setColumnSelectionAllowed(true);
		table.setCellSelectionEnabled(true);
		table.setBorder(new BevelBorder(BevelBorder.RAISED, Color.CYAN, null, null, null));
		
		table.setBounds(32, 110, 1213, 536);
		//contentPane.add(table);
		
		String[] ColumnName= {"Mobile Number","last Name","First name","Middle Name","Address","City","State","PinCode","Email Address","Date","Flat No","HOst Last Name","Host First Name","Purpose"};
		DefaultTableModel model=new DefaultTableModel(new Object[][] {},ColumnName);
		model.addColumn(ColumnName);
		table.setModel(model);
		
		String mbno="";
		String fname="";
		String lname="";
		String mname="";
		String addr="";
		String City="";
		String State="";
		String pin="";
		String email="";
		String date="";
		String flatno="";
		String hostlname="";
		String hostfname="";
		String Purpose="";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");  
		Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/ABC","root","Sanket@123");
		PreparedStatement stmt=con.prepareStatement("select * from vdetails");
		ResultSet rs=stmt.executeQuery();
		
		int i=1;
		model.addColumn("mobile no");
		while(rs.next())
		{
			
			mbno=rs.getString(1);
			lname=rs.getString(2);
			fname=rs.getString(3);
			mname=rs.getString(4);
			addr=rs.getString(5);
			City=rs.getString(6);
			State=rs.getString(7);
			pin=rs.getString(8);
			email=rs.getString(9);
			date=rs.getString(10);
			flatno=rs.getString(11);
			hostlname=rs.getString(12);
			hostfname=rs.getString(13);
			Purpose=rs.getString(14);
			model.addRow(new Object[]{i,mbno ,fname,lname,mname,addr,City,State,pin,email,date,flatno,hostlname,hostfname,Purpose} );
			i++;
			
		}
		contentPane.add(table);
		
		JScrollBar scrollBar = new JScrollBar();
		scrollBar.setBounds(1238, 115, 17, 531);
		contentPane.add(scrollBar);
		
		JButton btnHome = new JButton("Home");
		btnHome.setFont(new Font("Liberation Serif", Font.BOLD, 22));
		btnHome.setBackground(UIManager.getColor("Button.light"));
		btnHome.setBounds(40, 659, 117, 46);
		contentPane.add(btnHome);
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				home frame = new home();
				frame.setVisible(true);
			}
		});
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				visitorsdetails frame = new visitorsdetails();
				frame.setVisible(true);
			}
		});
		btnBack.setFont(new Font("Liberation Serif", Font.BOLD, 22));
		btnBack.setBackground(UIManager.getColor("Button.focus"));
		btnBack.setBounds(175, 658, 117, 46);
		contentPane.add(btnBack);
		
		table_1 = new JTable();
		table_1.setFont(new Font("Montserrat Black", Font.ITALIC, 12));
		table_1.setForeground(Color.BLACK);
		table_1.setSurrendersFocusOnKeystroke(true);
		table_1.setShowVerticalLines(false);
		table_1.setBounds(32, 83, 1211, 20);
		contentPane.add(table_1);
		DefaultTableModel model2=new DefaultTableModel(new Object[][] {},ColumnName);

		model2.addRow(new Object[]{"SR","Mobile No." ,"First Name","Last Name","Middle Name","Address","City","State","Pin Code","Email","Date","Flat No.","LastName(H)","FirstName(H)","Purpose"} );

		table_1.setModel(model2);
			con.close();  			
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println("Error while connection datbase");
			e.printStackTrace();
		}
		
		setSize(1280,800);
	}
}
