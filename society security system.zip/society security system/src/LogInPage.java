import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.*;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
public class LogInPage
{
	private JFrame frame;
	private JTextField user;
	private JPasswordField password;
	public static void main(String[] args) 
	{
		
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try
				{
					LogInPage window = new LogInPage();
					window.frame.setVisible(true);
				}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LogInPage() 
	{
		initialize();
	}
	private void initialize() 
	{
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblLogin = new JLabel("LogIn");
		lblLogin.setFont(new Font("DejaVu Serif", Font.BOLD, 25));
		lblLogin.setBackground(Color.PINK);
		lblLogin.setBounds(154, 33, 209, 43);
		frame.getContentPane().add(lblLogin);
		
		JLabel pass = new JLabel("Username");
		pass.setFont(new Font("Dialog", Font.BOLD, 15));
		pass.setBounds(51, 91, 98, 35);
		frame.getContentPane().add(pass);
		
		JLabel lblNewLabel = new JLabel("Password");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNewLabel.setBounds(51, 144, 108, 25);
		frame.getContentPane().add(lblNewLabel);
		
		user = new JTextField();
		user.setBounds(174, 96, 199, 25);
		frame.getContentPane().add(user);
		user.setColumns(10);
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				try {//mysql-connector-java-8.0.28.tar.gz
					Class.forName("com.mysql.cj.jdbc.Driver");  
					Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/ABC","root","Sanket@123");  
					Statement stmt=con.createStatement();  
					
					ResultSet rs=stmt.executeQuery("select * from username_pass where username='"+user.getText()+"' and password='"+password.getText().toString()+"'");  
					if(rs.next())  
					{
						JOptionPane.showMessageDialog(null, "login Successfully....");  
						home frm=new home();
						frm.setVisible(true);
					}	
					else
						JOptionPane.showMessageDialog(null, "Incorrect Username and Password....");
					con.close();  			
				} catch (SQLException | ClassNotFoundException e) {
					System.out.println("Error while connection datbase");
					e.printStackTrace();
				}
			}
		});
		btnOk.setBounds(51, 195, 131, 25);
		frame.getContentPane().add(btnOk);
		
		JButton btnCancel = new JButton("cancel");
		
		
		btnCancel.setBounds(241, 195, 132, 25);
		frame.getContentPane().add(btnCancel);
		btnCancel.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent args0)
			{
				second frm2=new second();
				frm2.setVisible(true);
			}
		});
		
		password = new JPasswordField();
		password.setBounds(177, 144, 199, 25);
		frame.getContentPane().add(password);
		ImageIcon background_image=new ImageIcon("/home/sanketjalindargaware/my phone/Anime/your name//best.jpg");
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(900, 600, Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		JLabel background=new JLabel("",background_image,JLabel.CENTER);
		//background.add(login);

		//background.add(heading);
		//background.setBounds(0,0,900,600);
		//add(background);
		//setVisible(true);
	}
}