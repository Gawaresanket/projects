import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class fourth extends JFrame
{
	fourth()
	{
		Font f=new Font("serif",Font.BOLD,30);
		Font f1=new Font("serif",Font.BOLD,50);

		
		
		
		//login pannel
		JPanel login=new JPanel();
		login.setLayout(null);
		login.setSize(200,100);
		login.setBackground(new Color(0,0,0,80));

		
		
		Container con=getContentPane();
		JLabel j1=new JLabel("Choose a block");
		j1.setBounds(235,0,800,200);
		j1.setForeground(Color.white);
		j1.setBackground(new Color(0,0,0,80));
		j1.setFont(f1);
		con.add(j1);
		
		//A block		
		JButton A=new JButton("A");
		A.setBounds(175,200,100,90);
		//A.setBackground(new Color(150,80,45));
		A.setFont(f1);
		login.add(A);
		A.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				FIve frm=new FIve();
				frm.setVisible(true);
			}
		});
		//B block
		JButton B=new JButton("B");
		B.setBounds(425,200,100,90);
		//B.setBackground(new Color(150,80,45));
		B.setFont(f1);
		login.add(B);
		B.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				FIve1 frm1=new FIve1();
				frm1.setVisible(true);
			}
		});
		
		//C block
		JButton C=new JButton("C");
		C.setBounds(175,350,100,90);
		//C.setBackground(new Color(150,80,45));
		C.setFont(f1);
		login.add(C);
		C.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				FIve2 frm2=new FIve2();
				frm2.setVisible(true);
			}
		});
		
		//D block
		JButton D=new JButton("D");
		D.setBounds(425,350,100,90);
		//D.setBackground(new Color(150,80,45));
		D.setFont(f1);
		login.add(D);
		D.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				FIve3 frm3=new FIve3();
				frm3.setVisible(true);
			}
		});
		
				
		//login button
		JButton login_button=new JButton("Prev");
		login_button.setBounds(300,500,90,30);
		login.add(login_button);
		
		login_button.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent args0)
			{
				demo frm1=new demo();
				frm1.setVisible(true);
			}
		});
		
		login.setBounds(100,0,700,575);

		
		//frame
		setSize(900,600);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//image
		ImageIcon background_image=new ImageIcon("//home//sanketjalindargaware//Desktop//yourname.jpg");
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(900, 600, Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		JLabel background=new JLabel("",background_image,JLabel.CENTER);
		background.add(login);


		background.setBounds(0,0,900,600);
		add(background);
		setVisible(true);
	}
	public static void main(String[] args) 
	{
		new fourth();
		
	}

}
