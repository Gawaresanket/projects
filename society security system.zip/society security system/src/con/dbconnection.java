package con;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class dbconnection
{

	public static void main(String[] args) 
	{
		try {//mysql-connector-java-8.0.28.tar.gz
			Class.forName("com.mysql.cj.jdbc.Driver");  
		Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/xyz","root","Sanket@123");
			System.out.println("connectio successfully.....");
			con.close();  			
		} catch (SQLException | ClassNotFoundException e) {
			System.out.println("Error while connection datbase");
			e.printStackTrace();
		}

	}

}
