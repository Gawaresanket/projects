import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
public class LogIn
{
	private JFrame frame;
	private JTextField user;
	private JPasswordField password;
	public static void main(String[] args) 
	{
		
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try
				{
					LogIn window = new LogIn();
					window.frame.setVisible(true);
				}
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LogIn() 
	{
		initialize();
	}
	private void initialize() 
	{
		frame = new JFrame();
		frame.setBounds(100, 100, 1280, 800);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblLogin = new JLabel("LogIn");
		lblLogin.setFont(new Font("DejaVu Serif", Font.BOLD, 25));
		lblLogin.setBackground(Color.PINK);
		lblLogin.setBounds(698, 131, 209, 43);
		frame.getContentPane().add(lblLogin);
		
		JLabel pass = new JLabel("Username");
		pass.setFont(new Font("Dialog", Font.BOLD, 15));
		pass.setBounds(508, 233, 98, 35);
		frame.getContentPane().add(pass);
		
		JLabel lblNewLabel = new JLabel("Password");
		lblNewLabel.setFont(new Font("Dialog", Font.BOLD, 15));
		lblNewLabel.setBounds(523, 320, 108, 25);
		frame.getContentPane().add(lblNewLabel);
		
		user = new JTextField();
		user.setBounds(649, 243, 199, 25);
		frame.getContentPane().add(user);
		user.setColumns(10);
		
		JButton btnOk = new JButton("OK");
		btnOk.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				try {//mysql-connector-java-8.0.28.tar.gz
					Class.forName("com.mysql.cj.jdbc.Driver");  
					Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/ABC","root","Sanket@123");  
					Statement stmt=con.createStatement();  
					
					ResultSet rs=stmt.executeQuery("select * from username_pass where username='"+user.getText()+"' and password='"+password.getText().toString()+"'");  
					if(rs.next())  
					{
						JOptionPane.showMessageDialog(null, "login Successfully....");  
					//	home frm=new home();
						//frm.setVisible(true);
					}	
					else
						JOptionPane.showMessageDialog(null, "Incorrect Username and Password....");
					con.close();  			
				} catch (SQLException | ClassNotFoundException e) {
					System.out.println("Error while connection datbase");
					e.printStackTrace();
				}
			}
		});
		btnOk.setBounds(521, 398, 131, 25);
		frame.getContentPane().add(btnOk);
		
		JButton btnCancel = new JButton("cancel");
		
		
		btnCancel.setBounds(753, 398, 132, 25);
		frame.getContentPane().add(btnCancel);
		btnCancel.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent args0)
			{
			//	second frm2=new second();
				//frm2.setVisible(true);
			}
		});
		
		password = new JPasswordField();
		password.setBounds(649, 341, 199, 25);
		frame.getContentPane().add(password);
	//	setSize(1280,800);

	}
}