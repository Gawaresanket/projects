import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.*;
public class third extends JFrame
{
	third()
	{
		Font f=new Font("serif",Font.BOLD,30);
		Font f1=new Font("serif",Font.BOLD,20);


		
		
		//login pannel
		JPanel login=new JPanel();
		login.setLayout(null);
		login.setSize(1280,800);
		login.setBackground(new Color(0,0,0,0));

		
		
		Container con=getContentPane();
		con.setBackground(UIManager.getColor("EditorPane.inactiveForeground"));

		JLabel j1=new JLabel("Enter Username");
		j1.setBounds(200,150,400,80);
		j1.setForeground(Color.white);
		j1.setBackground(new Color(0,0,0,80));
		j1.setFont(f1);
		con.add(j1);
		
		JLabel j2=new JLabel("Enter Password");
		j2.setBounds(200,200,400,80);
		j2.setForeground(Color.white);
		j2.setBackground(new Color(0,0,0,80));
		j2.setFont(f1);
		con.add(j2);

		
		JLabel j3=new JLabel("Conform Password");
		j3.setBounds(200,250,400,80);
		j3.setForeground(Color.white);
		j3.setBackground(new Color(0,0,0,80));
		j3.setFont(f1);
		con.add(j3);
		
				
		JTextField username=new JTextField("");
		username.setBounds(300,30,200,25);
		username.setOpaque(false);
		username.setForeground(Color.gray);
		username.setBackground(new Color(210,180,140));
		login.add(username);
		
		JTextField password=new JTextField("");
		password.setBounds(300,80,200,25);
		password.setOpaque(false);
		password.setForeground(Color.gray);
		password.setBackground(new Color(210,180,140));
		login.add(password);
		
		JTextField username1=new JTextField("");
		username1.setBounds(300,130,200,25);
		username1.setOpaque(false);
		username1.setForeground(Color.gray);
		username1.setBackground(new Color(210,180,140));
		login.add(username1);
		
		
		//signup button
		JButton signup=new JButton("Create");
		signup.setBounds(350,300,90,30);
		//signup.setBackground(new Color(150,80,45));
		login.add(signup);
		
		signup.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent args0)
			{
				h1 frm2=new h1();
				frm2.setVisible(true);
			}
		});
		
		
		//login button
		JButton login_button=new JButton("Cancle");
		login_button.setBounds(100,300,90,30);
		//login_button.setBackground(new Color(120,182,40));
		login.add(login_button);
		
		login_button.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent args0)
			{
				second frm=new second();
				frm.setVisible(true);
			}
		});
		
		
		
		login.setBounds(145,145,600,375);

		//frame
		setSize(900,600);
		setLayout(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		//image
		ImageIcon background_image=new ImageIcon("//home//sanketjalindargaware//Downloads//flex-point-security-ut4dQ0KqsQE-unsplash.jpg");
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1280, 800, Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		JLabel background=new JLabel("",background_image,JLabel.CENTER);
		background.add(login);
		background.setBounds(0,0,900,600);
		add(background);
		setVisible(true);
		
		signup.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");  
					Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/ABC","root","Sanket@123");  
					String a=username.getText();
					String b=password.getText();
					String c=username1.getText();
					

					String s="insert into username_password values('"+a+"','"+b+"','"+c+"')";
					PreparedStatement stmt=con.prepareStatement(s);
					stmt.execute();
					System.out.println("success");
					
					con.close();  			
				} catch (SQLException | ClassNotFoundException e) {
					System.out.println("Error while connection datbase");
					e.printStackTrace();
				}
			}
		});
	}
	public static void main(String[] args) 
	{
		new third();
		
	
		
	}

}
