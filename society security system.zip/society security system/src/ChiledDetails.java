import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.awt.Button;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChiledDetails extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ChiledDetails frame = new ChiledDetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ChiledDetails() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(UIManager.getColor("Button.shadow"));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Child Details");
		lblNewLabel.setFont(new Font("Liberation Serif", Font.BOLD, 24));
		lblNewLabel.setBounds(609, 26, 191, 40);
		contentPane.add(lblNewLabel);
		
		table = new JTable();
		table.setBounds(45, 370, 1184, 331);
		contentPane.add(table);
		
		JLabel lblName = new JLabel("Frist Name:");
		lblName.setBounds(66, 127, 123, 15);
		contentPane.add(lblName);
		
		textField = new JTextField();
		textField.setBounds(165, 118, 205, 34);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblMobileNo = new JLabel("Mobile No:");
		lblMobileNo.setBounds(465, 117, 96, 34);
		contentPane.add(lblMobileNo);
		
		textField_1 = new JTextField();
		textField_1.setBounds(559, 118, 198, 34);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		Button button = new Button("Add");
		button.setFont(new Font("Liberation Serif", Font.BOLD, 18));
		button.setBackground(UIManager.getColor("MenuItem.acceleratorForeground"));
		button.setBounds(66, 283, 205, 40);
		contentPane.add(button);
		
		Button button_1 = new Button("Back");
		button_1.setFont(new Font("Liberation Serif", Font.BOLD, 18));
		button_1.setBackground(UIManager.getColor("CheckBoxMenuItem.acceleratorForeground"));
		button_1.setBounds(356, 283, 205, 40);
		contentPane.add(button_1);
		button_1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent args0)
			{
				home frm2=new home();
				frm2.setVisible(true);
			}
		});
				
		
		JLabel lblFlatNo = new JLabel("Flat no:");
		lblFlatNo.setBounds(837, 127, 70, 15);
		contentPane.add(lblFlatNo);
		
		textField_2 = new JTextField();
		textField_2.setBounds(925, 118, 183, 34);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		setSize(1280,800);

	}
}
