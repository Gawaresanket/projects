import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class home extends JFrame
{
	home()
	{
		setBackground(UIManager.getColor("Button.foreground"));
		getContentPane().setForeground(Color.WHITE);
		getContentPane().setBackground(new Color(51, 0, 204));
		Font f=new Font("serif",Font.BOLD,30);
		//header
		JPanel heading,h1,h2;

		//frame
		setSize(1280,800);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		
		JButton btnNewButton = new JButton("Log Out");
		btnNewButton.setBounds(564, 552, 117, 25);
		getContentPane().add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				logout frm12=new logout();
				frm12.setVisible(true);
			}
		});
		
		JButton btnBack = new JButton("Back");
		btnBack.setBounds(564, 503, 117, 25);
		getContentPane().add(btnBack);
		btnBack.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				fourth frm1=new fourth();
				frm1.setVisible(true);
			}
		});
		
		
	
		
		
		
		JPanel login1=new JPanel();
		login1.setBounds(-11, 112, 1, 600);
		login1.setBorder(UIManager.getBorder("Menu.border"));
		getContentPane().add(login1);
		login1.setLayout(null);
		login1.setBackground(new Color(ALLBITS));

		
		heading=new JPanel();
		heading.setBounds(0, 0, 1285, 30);
		getContentPane().add(heading);
		heading.setBackground(new Color(255, 255, 102));
		
		JLabel background=new JLabel();
		heading.add(background);
		JLabel name=new JLabel("Welcome to Society Security System");
		name.setForeground(Color.BLACK);
		name.setBounds(300,80,600,100);
		name.setFont(new Font("Serif", Font.BOLD, 20));
		heading.add(name);
		
		JPanel panel = new JPanel();
		panel.setBounds(207, 372, 279, 156);
		panel.setBorder(UIManager.getBorder("FormattedTextField.border"));
		panel.setToolTipText("hfhjghsdh");
		getContentPane().add(panel);
		panel.setBackground(new Color(102, 204, 204));
		panel.setLayout(null);
		
		JLabel lblAddVisitorsDetails = new JLabel("Add Visitors Details");
		lblAddVisitorsDetails.setFont(new Font("Dialog", Font.BOLD, 22));
		lblAddVisitorsDetails.setBounds(12, 5, 267, 139);
		panel.add(lblAddVisitorsDetails);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.setBounds(75, 119, 117, 25);
		panel.add(btnAdd);
		btnAdd.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				visitorsdetails frm=new visitorsdetails();
				frm.setVisible(true);
			}
		});

		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(770, 372, 265, 156);
		panel_1.setBorder(UIManager.getBorder("FormattedTextField.border"));
		getContentPane().add(panel_1);
		panel_1.setBackground(new Color(102, 204, 204));
		panel_1.setLayout(null);
		
		JLabel lblAddChildrenDetails = new JLabel("Add Children Details");
		lblAddChildrenDetails.setFont(new Font("Dialog", Font.BOLD, 20));
		lblAddChildrenDetails.setBounds(12, 0, 313, 157);
		panel_1.add(lblAddChildrenDetails);
		
		JButton btnAdd_2 = new JButton("Add");
		btnAdd_2.setBounds(72, 119, 117, 25);
		panel_1.add(btnAdd_2);
		btnAdd_2.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				ChiledDetails frm=new ChiledDetails();
				frm.setVisible(true);
			}
		});
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(207, 552, 279, 160);
		panel_2.setBorder(UIManager.getBorder("FormattedTextField.border"));
		getContentPane().add(panel_2);
		panel_2.setBackground(new Color(102, 204, 204));
		panel_2.setLayout(null);
		
		JLabel lblAddOwnerDetails = new JLabel("Add Owner Details");
		lblAddOwnerDetails.setFont(new Font("Dialog", Font.BOLD, 22));
		lblAddOwnerDetails.setBounds(12, 5, 267, 107);
		panel_2.add(lblAddOwnerDetails);
		
		JButton btnAdd_1 = new JButton("Add");
		btnAdd_1.setBounds(79, 123, 117, 25);
		panel_2.add(btnAdd_1);
		btnAdd_1.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				ownerdetails frm1=new ownerdetails();
				frm1.setVisible(true);
			}
		});
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(770, 552, 265, 160);
		panel_3.setBorder(UIManager.getBorder("FormattedTextField.border"));
		getContentPane().add(panel_3);
		panel_3.setBackground(new Color(102, 204, 204));
		panel_3.setLayout(null);
		
		JLabel lblAddStaffDetails = new JLabel("Add Staff Details");
		lblAddStaffDetails.setFont(new Font("Dialog", Font.BOLD, 22));
		lblAddStaffDetails.setBounds(23, 12, 219, 105);
		panel_3.add(lblAddStaffDetails);
		
		JButton btnAdd_3 = new JButton("Add");
		btnAdd_3.setBounds(67, 123, 117, 25);
		panel_3.add(btnAdd_3);
		btnAdd_3.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				staffdetails frm2=new staffdetails();
				frm2.setVisible(true);
			}
		});
		/*JLabel label1=new JLabel("");
		
		label1.setBounds(2,12,1283,326);
		getContentPane().add(label1);*/
		
		ImageIcon background_image=new ImageIcon("//home//sanketjalindargaware//Downloads//fly-d-mT7lXZPjk7U-unsplash (1).jpg");
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1285, 800, Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		JLabel background3=new JLabel("",background_image,JLabel.CENTER);
		background3.setBounds(0, 0, 1285, 736);
		getContentPane().add(background3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(10, 116, 1283, 326);
		getContentPane().add(panel_4);
		//getContentPane().add(panel_4);
		panel_4.setBackground(new Color(0,0,0,10));
		setVisible(true);
		

	}
	public static void main(String[] args) 
	{
		new home();
		
	}
}
