import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.UIManager;
import java.awt.SystemColor;

public class FIve1 extends JFrame {

	public JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FIve frame = new FIve();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FIve1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setBounds(1285, 800, 1163, 492);
		setSize(1285,800);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 102, 0));
		contentPane.setBorder(new BevelBorder(15));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSelectFlatNo = new JLabel("Select Flat No");
		lblSelectFlatNo.setBackground(new Color(204, 255, 0));
		lblSelectFlatNo.setFont(new Font("Dialog", Font.BOLD | Font.ITALIC, 30));
		lblSelectFlatNo.setForeground(new Color(204, 255, 0));
		lblSelectFlatNo.setBounds(510, 12, 331, 77);
		contentPane.add(lblSelectFlatNo);
		
		JButton button = new JButton("201");
		button.setForeground(Color.BLACK);
		button.setBackground(SystemColor.windowBorder);
		button.setBounds(338, 164, 117, 77);
		contentPane.add(button);
		button.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent args0)
			{
				home frm=new home();
				frm.setVisible(true);
			}
		});
		
		JButton button_1 = new JButton("202");
		button_1.setBackground(SystemColor.windowBorder);
		button_1.setBounds(781, 164, 117, 77);
		contentPane.add(button_1);
		button_1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent args0)
			{
				home frm=new home();
				frm.setVisible(true);
			}
		});
		
		JButton button_2 = new JButton("203");
		button_2.setBackground(SystemColor.windowBorder);
		button_2.setBounds(338, 484, 117, 77);
		contentPane.add(button_2);
		button_2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent args0)
			{
				newhome frm=new newhome();
				frm.setVisible(true);
			}
		});
		
		JButton button_3 = new JButton("204");
		button_3.setBackground(SystemColor.windowBorder);
		button_3.setBounds(781, 484, 117, 77);
		contentPane.add(button_3);
		button_3.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent args0)
			{
				home frm=new home();
				frm.setVisible(true);
			}
		});
		
		JButton button_4 = new JButton("205");
		button_4.setBackground(SystemColor.windowBorder);
		button_4.setBounds(568, 315, 117, 77);
		contentPane.add(button_4);
		button_4.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent args0)
			{
				home frm=new home();
				frm.setVisible(true);
			}
		});
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(UIManager.getColor("CheckBoxMenuItem.selectionBackground"));
		btnBack.setBounds(568, 615, 117, 25);
		contentPane.add(btnBack);
		btnBack.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent args0)
			{
				fourth frm=new fourth();
				frm.setVisible(true);
			}
		});
		
	
	}
}
