import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
public class newhome extends JFrame
{
	newhome()
	{
		getContentPane().setForeground(Color.WHITE);
		getContentPane().setBackground(Color.WHITE);
		Font f=new Font("serif",Font.BOLD,30);
		//header
		JPanel heading,h1,h2;

		//frame
		setSize(1280,800);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		
	
		
		
		
		JPanel login1=new JPanel();
		login1.setBounds(-11, 112, 1, 600);
		getContentPane().add(login1);
		login1.setLayout(null);
		login1.setBackground(new Color(ALLBITS));

		
		heading=new JPanel();
		heading.setBounds(0, 0, 1285, 30);
		getContentPane().add(heading);
		heading.setBackground(new Color(255, 255, 102));
		
		JLabel background=new JLabel();
		heading.add(background);
		JLabel name=new JLabel("Welcome to Society Security System");
		name.setForeground(Color.BLACK);
		name.setBounds(300,80,600,100);
		name.setFont(new Font("Serif", Font.BOLD, 20));
		heading.add(name);
		/*JLabel label1=new JLabel("");
		
		label1.setBounds(2,12,1283,326);
		getContentPane().add(label1);*/
		//rootPaneCheckingEnabled
		ImageIcon background_image=new ImageIcon("//home//sanketjalindargaware//Downloads//20220426_205348.jpg");
		Image img=background_image.getImage();
		Image temp_img=img.getScaledInstance(1285, 800, Image.SCALE_SMOOTH);
		background_image=new ImageIcon(temp_img);
		JLabel background3=new JLabel("",background_image,JLabel.CENTER);
		background3.setBounds(-32, -71, 1285, 807);
		background3.setForeground(Color.BLACK);
		getContentPane().add(background3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(-11, -85, 1283, 326);
		getContentPane().add(panel_4);
		//getContentPane().add(panel_4);
		panel_4.setBackground(new Color(0,0,0,10));
		panel_4.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(12, 261, 376, 189);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblInsertVisitorsCheck = new JLabel("Insert visitors check in details with carefully");
		lblInsertVisitorsCheck.setBounds(12, 0, 352, 177);
		panel.add(lblInsertVisitorsCheck);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(12, 514, 376, 210);
		getContentPane().add(panel_1);
		setVisible(true);

	}
	public static void main(String[] args) 
	{
		new newhome();
		
	}
}
