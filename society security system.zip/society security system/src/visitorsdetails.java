import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

public class visitorsdetails extends JFrame {

	private JPanel contentPane;
	private JTextField lname;
	private JTextField fname;
	private JTextField mname;
	private JTextField mbno;
	private JTextField addr;
	private JTextField City;
	private JTextField State;
	private JTextField pin;
	private JTextField email;
	private JLabel lblWhoIsThe;
	private JTextField flatno;
	private JTextField hostlname;
	private JTextField hostfname;
	private JLabel lblPuroseOfVisit;
	private JTextField Purpose;
	private JPanel panel_2;
	private JPanel panel_3;
	private JPanel panel_4;
	private JLabel lblFirstName_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					visitorsdetails frame = new visitorsdetails();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public visitorsdetails() {
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(UIManager.getColor("EditorPane.inactiveForeground"));
		contentPane.setBorder(UIManager.getBorder("InternalFrame.border"));
		setContentPane(contentPane);
		setSize(1280,800);
		getContentPane().setLayout(null);
		contentPane.setLayout(null);
		
		JLabel lblDetailsOfVisitor = new JLabel("Details of Visitor");
		lblDetailsOfVisitor.setFont(new Font("Jomolhari", Font.BOLD, 35));
		lblDetailsOfVisitor.setForeground(new Color(128, 0, 0));
		lblDetailsOfVisitor.setBounds(523, 12, 382, 72);
		contentPane.add(lblDetailsOfVisitor);
		
		JLabel lblEnterTheFull = new JLabel("Enter the full Name of Visitor");
		lblEnterTheFull.setFont(new Font("Liberation Serif", Font.BOLD, 20));
		lblEnterTheFull.setForeground(new Color(0, 0, 0));
		lblEnterTheFull.setBounds(450, 67, 476, 49);
		contentPane.add(lblEnterTheFull);
		
		lname = new JTextField();
		lname.setText("Enter Last name first");
		lname.setBounds(450, 125, 233, 39);
		contentPane.add(lname);
		lname.setColumns(10);
		
		fname = new JTextField();
		fname.setText("Enter First Name");
		fname.setBounds(450, 187, 233, 39);
		contentPane.add(fname);
		fname.setColumns(10);
		
		mname = new JTextField();
		mname.setToolTipText("");
		mname.setText("Enter Middle Name");
		mname.setBounds(450, 247, 233, 39);
		contentPane.add(mname);
		mname.setColumns(10);
		
		JLabel lblEnterPhoneNumber = new JLabel("Enter Phone Number");
		lblEnterPhoneNumber.setForeground(new Color(0, 0, 0));
		lblEnterPhoneNumber.setFont(new Font("Liberation Serif", Font.BOLD, 20));
		lblEnterPhoneNumber.setBounds(450, 316, 277, 39);
		contentPane.add(lblEnterPhoneNumber);
		
		mbno = new JTextField();
		mbno.setText("Enter Valid Phone No");
		mbno.setBounds(450, 362, 233, 39);
		contentPane.add(mbno);
		mbno.setColumns(10);
		
		JLabel lblVisitorsHomeAddress = new JLabel("Visitor's Home Address");
		lblVisitorsHomeAddress.setForeground(Color.BLACK);
		lblVisitorsHomeAddress.setFont(new Font("Liberation Serif", Font.BOLD, 20));
		lblVisitorsHomeAddress.setBounds(450, 425, 218, 49);
		contentPane.add(lblVisitorsHomeAddress);
		
		addr = new JTextField();
		addr.setText("Street Address");
		addr.setBounds(450, 478, 233, 39);
		contentPane.add(addr);
		addr.setColumns(10);
		
		City = new JTextField();
		City.setText("City");
		City.setBounds(450, 539, 233, 39);
		contentPane.add(City);
		City.setColumns(10);
		
		State = new JTextField();
		State.setText("State");
		State.setBounds(450, 603, 233, 39);
		contentPane.add(State);
		State.setColumns(10);
		
		pin = new JTextField();
		pin.setText("Pin Code");
		pin.setBounds(450, 664, 233, 39);
		contentPane.add(pin);
		pin.setColumns(10);
		
		JLabel lblEmailAddress = new JLabel("Email Address");
		lblEmailAddress.setFont(new Font("Liberation Serif", Font.BOLD, 20));
		lblEmailAddress.setBounds(850, 76, 233, 31);
		contentPane.add(lblEmailAddress);
		
		email = new JTextField();
		email.setText("sample123@gmail.com");
		email.setBounds(840, 135, 254, 39);
		contentPane.add(email);
		email.setColumns(10);
		
		lblWhoIsThe = new JLabel("Who is the Visitors Host?");
		lblWhoIsThe.setForeground(Color.BLACK);
		lblWhoIsThe.setFont(new Font("Liberation Serif", Font.BOLD, 20));
		lblWhoIsThe.setBounds(839, 205, 244, 31);
		contentPane.add(lblWhoIsThe);
		
		flatno = new JTextField();
		flatno.setText("Flat No");
		flatno.setBounds(850, 247, 244, 39);
		contentPane.add(flatno);
		flatno.setColumns(10);
		
		hostlname = new JTextField();
		hostlname.setText("Host Last Name");
		hostlname.setBounds(850, 317, 244, 39);
		contentPane.add(hostlname);
		hostlname.setColumns(10);
	
		hostfname = new JTextField();
		hostfname.setText("Host First Name");
		hostfname.setBounds(850, 385,244, 39);
		
		contentPane.add(hostfname);
		hostfname.setColumns(10);
		
		lblPuroseOfVisit = new JLabel("Purose of Visit?");
		lblPuroseOfVisit.setForeground(Color.BLACK);
		lblPuroseOfVisit.setFont(new Font("Liberation Serif", Font.BOLD, 20));
		lblPuroseOfVisit.setBounds(850, 430, 218, 39);
		contentPane.add(lblPuroseOfVisit);
		
		Purpose = new JTextField();
		Purpose.setBounds(850, 467, 244, 217);
		contentPane.add(Purpose);
		Purpose.setColumns(10);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(75, 0, 130));
		panel.setBounds(12, 12, 277, 712);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.addMouseListener(new MouseAdapter() {
			
			
			public void mouseClicked(MouseEvent e) {
				home frm=new home();
				frm.setVisible(true);
			}
		});
		panel_1.setBounds(12, 23, 253, 62);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		
		JLabel lblHome = new JLabel("Home");
		lblHome.setFont(new Font("Nimbus Roman", Font.BOLD, 20));
		lblHome.setBounds(80, 12, 132, 38);
		panel_1.add(lblHome);
		
		panel_2 = new JPanel();
		panel_2.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				ShowDetails frame = new ShowDetails();
				frame.setVisible(true);
			}
		});
		panel_2.setBounds(12, 97, 253, 62);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblShowDetails = new JLabel("Show Details");
		lblShowDetails.setForeground(new Color(0, 0, 0));
		lblShowDetails.setFont(new Font("Nimbus Roman", Font.BOLD, 20));
		lblShowDetails.setBounds(65, 12, 140, 38);
		panel_2.add(lblShowDetails);
		
		panel_3 = new JPanel();
		panel_3.setBounds(12, 171, 253, 62);
		panel.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblClear = new JLabel("Clear");
		lblClear.setFont(new Font("Nimbus Roman", Font.BOLD, 20));
		lblClear.setBounds(69, 12, 109, 38);
		panel_3.add(lblClear);
		panel_3.addMouseListener(new MouseAdapter() {
			
			public void mouseClicked(MouseEvent e) {
				Purpose.setText("");
				email.setText("");
				lname.setText("");
				fname.setText("");
				mname.setText("");
				mbno.setText("");
				addr.setText("");
				City.setText("");
				State.setText("");
				pin.setText("");
			//	date.setText("");
				flatno.setText("");
				hostlname.setText("");
				hostfname.setText("");
			}
		});
		
		panel_4 = new JPanel();
		panel_4.setBounds(12, 245, 253, 62);
		panel.add(panel_4);
		panel_4.setLayout(null);
		
		
		
		JLabel lblBack = new JLabel("Submit");
		lblBack.setFont(new Font("Nimbus Roman", Font.BOLD, 20));
		lblBack.setBounds(74, 12, 106, 38);
		panel_4.add(lblBack);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBounds(12, 309, 253, 391);
		panel.add(panel_5);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		panel_5.setBackground(new Color(0,0,0,80));
		
		JLabel lblFirstName = new JLabel("Last Name:");
		lblFirstName.setFont(new Font("Dialog", Font.PLAIN, 12));
		lblFirstName.setBounds(348, 137, 103, 15);
		contentPane.add(lblFirstName);
		
		lblFirstName_1 = new JLabel("First Name");
		lblFirstName_1.setFont(new Font("Dialog", Font.PLAIN, 12));
		lblFirstName_1.setBounds(348, 187, 70, 15);
		contentPane.add(lblFirstName_1);
		
		JLabel lblMiddleName = new JLabel("Middle Name");
		lblMiddleName.setFont(new Font("Dialog", Font.PLAIN, 12));
		lblMiddleName.setBounds(348, 247, 103, 15);
		contentPane.add(lblMiddleName);
		
		JLabel lblPhoneNo = new JLabel("Phone No.");
		lblPhoneNo.setFont(new Font("Dialog", Font.PLAIN, 12));
		lblPhoneNo.setBounds(348, 362, 70, 15);
		contentPane.add(lblPhoneNo);
		
		JLabel lblStreetAddress = new JLabel("Street Address");
		lblStreetAddress.setFont(new Font("Dialog", Font.PLAIN, 12));
		lblStreetAddress.setBounds(348, 478, 103, 15);
		contentPane.add(lblStreetAddress);
		
		JLabel lblCity = new JLabel("City");
		lblCity.setFont(new Font("Dialog", Font.PLAIN, 12));
		lblCity.setBounds(348, 539, 70, 15);
		contentPane.add(lblCity);
		
		JLabel lblState = new JLabel("State");
		lblState.setFont(new Font("Dialog", Font.PLAIN, 12));
		lblState.setBounds(348, 603, 70, 15);
		contentPane.add(lblState);
		
		JLabel lblPinCode = new JLabel("Pin Code");
		lblPinCode.setFont(new Font("Dialog", Font.PLAIN, 12));
		lblPinCode.setBounds(348, 664, 70, 15);
		contentPane.add(lblPinCode);
		
		JLabel lblEmailAddress_1 = new JLabel("Email Address");
		lblEmailAddress_1.setFont(new Font("Dialog", Font.PLAIN, 12));
		lblEmailAddress_1.setBounds(734, 137, 88, 15);
		contentPane.add(lblEmailAddress_1);
		
		JLabel lblFlatNo = new JLabel("Flat No.");
		lblFlatNo.setFont(new Font("Dialog", Font.PLAIN, 12));
		lblFlatNo.setBounds(734, 247, 70, 15);
		contentPane.add(lblFlatNo);
		
		JLabel lblHostLastName = new JLabel("Host Last Name");
		lblHostLastName.setFont(new Font("Dialog", Font.PLAIN, 12));
		lblHostLastName.setBounds(734, 316, 118, 15);
		contentPane.add(lblHostLastName);
		
		JLabel lblHostFirstName = new JLabel("Host First Name");
		lblHostFirstName.setFont(new Font("Dialog", Font.PLAIN, 12));
		lblHostFirstName.setBounds(734, 386, 118, 15);
		contentPane.add(lblHostFirstName);
		SimpleDateFormat fdate=new SimpleDateFormat("yyyy/MM/dd");
		Date date=new Date();		
		
		panel_4.addMouseListener(new MouseAdapter() {
			
			
			public void mouseClicked(MouseEvent e) {
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");  
					Connection con=DriverManager.getConnection( "jdbc:mysql://localhost:3306/ABC","root","Sanket@123");  
					String a=mbno.getText();
					String b=fname.getText();
					String c=lname.getText();
					String d=mname.getText();
					String y=addr.getText();
					String f=City.getText();
					String g=State.getText();
					String h=pin.getText();
					String D=email.getText();
					//String i=date.getText();
					String z=flatno.getText();
					int j=Integer.parseInt(z);
					String k=hostlname.getText();
					String l=hostfname.getText();
					String m=Purpose.getText();
					

					String s="insert into vdetails values('"+a+"','"+b+"','"+c+"','"+d+"','"+y+"','"+f+"','"+g+"','"+h+"','"+D+"','"+fdate.format(date)+"','"+j+"','"+k+"','"+l+"','"+m+"')";
					PreparedStatement stmt=con.prepareStatement(s);
					stmt.execute();
					System.out.println("success");
					visitorsdetails frame1=new visitorsdetails();
					JOptionPane.showMessageDialog(frame1,"The Details has been Successfully Submited!!!");
					
					con.close();  			
				} catch (SQLException | ClassNotFoundException x) {
					System.out.println("Error while connection datbase");
					x.printStackTrace();
				}
			}
		});
		
	}
}
